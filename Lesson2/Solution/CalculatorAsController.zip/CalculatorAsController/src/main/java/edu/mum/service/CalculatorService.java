package edu.mum.service;

import edu.mum.domain.Calculator;

public interface CalculatorService {

	
	public void add(Calculator calculator);
	
	public void mult(Calculator calculator);

}
